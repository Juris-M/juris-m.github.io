##### connectorTypeSchemaData.js

This file is generated in the Zotero client with `tools/build_typeSchemaData.html`
and then loaded by `cachedTypes.js` in this repository. It's a 